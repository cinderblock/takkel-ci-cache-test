# @takkel/helper-linux-x64-musl

The linux-x64-musl build of the native addon in [@takkel/helper](https://www.npmjs.com/package/@takkel/helper). Install @takkel/helper, not this package: it depends on this one as an optional dependency, and the package manager installs only the one for your platform.
