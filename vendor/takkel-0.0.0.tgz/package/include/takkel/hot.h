/*
 * takkel/hot.h: hot shared libraries without Node (architecture.md 6.6). Single header, C or C++, no dependencies
 * beyond the OS's loader (kernel32 on Windows, libdl or libc elsewhere). A target marked `hot: true` in
 * takkel.yaml has this header on its include path.
 *
 * The library: a `shared-library` target with `hot: true`. Export what the host calls with TAKKEL_HOT_EXPORT.
 * Optionally export two hooks, called on the host's thread when a generation is switched:
 *
 *     TAKKEL_HOT_EXPORT void takkel_hot_on_unload(void **state, int generation);   // before leaving it
 *     TAKKEL_HOT_EXPORT void takkel_hot_on_load(void **state, int generation);     // after switching to it
 *
 * `*state` is the host's, kept across generations, so a library can hand its state to the next generation (or
 * tear it down and build it again). Background threads a generation started must be stopped in on_unload.
 *
 * The host: a program marked `hot: true`. It names the functions it wants, gets a table of pointers, and calls
 * takkel_hot_update() from its main loop; when tak watch or tak dev has published a new generation, the next call
 * loads it and re-resolves the table.
 *
 *     typedef struct { int (*add)(int, int); } api_t;
 *     static const char *const names[] = { "add" };
 *     api_t api;
 *     takkel_hot lib;
 *     if (takkel_hot_open(&lib, "mathlib", NULL, (void **)&api, names, 1) != 0) die(lib.error);
 *     for (;;) {
 *       if (takkel_hot_update(&lib) < 0) fprintf(stderr, "%s\n", lib.error);   // the old generation stays
 *       printf("%d\n", api.add(2, 2));
 *     }
 *
 * The manifest is `<buildDir>/hot/<name>.json`, written by takkel: NULL finds it through TAKKEL_HOT_DIR, which
 * `tak dev` sets for its program; a host started some other way passes the path (".build/hot/mathlib.json").
 * Under `tak dev --hot` (TAKKEL_HOT set) each load is acknowledged in `hot/acks/<pid>-<name>.json`, so takkel
 * knows the swap worked, or restarts the program.
 *
 * Limits, as for Node addons: old generations stay loaded (code and data an old generation handed out stay
 * valid); state does not migrate unless the hooks move it; function pointers copied out of the table keep calling
 * the generation they came from. The table must be an array of `count` function pointers, which every supported
 * ABI lays out like a struct of them.
 */
#ifndef TAKKEL_HOT_H
#define TAKKEL_HOT_H

#if defined(_WIN32)
#define TAKKEL_HOT_EXPORT __declspec(dllexport)
#else
#define TAKKEL_HOT_EXPORT __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
#define TAKKEL_HOT_EXTERN_C extern "C"
#else
#define TAKKEL_HOT_EXTERN_C
#endif

#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if defined(_WIN32)
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#else
#include <dlfcn.h>
#include <errno.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*takkel_hot_hook)(void **state, int generation);

typedef struct takkel_hot {
  /** The library target's name, as in takkel.yaml. */
  char name[128];
  /** The manifest's path. */
  char manifest[4096];
  /** The loaded generation; 0 before the first. */
  int generation;
  /** The highest generation tried, so a broken one is not tried again on every update. */
  int tried;
  /** The host's state, handed to the hooks; kept across generations. */
  void *state;
  /** Why the last open or update failed. */
  char error[1024];
  void **table;
  const char *const *symbols;
  size_t count;
  void *handle;
  /** The manifest's size and modification time when last read: an unchanged file is not read again. */
  long long stamp_size;
  long long stamp_time;
} takkel_hot;

/* An environment variable into buf; empty when unset. (getenv is "unsafe" to MSVC.) */
static inline const char *takkel_hot__env(const char *name, char *buf, size_t size) {
#if defined(_WIN32)
  DWORD n = GetEnvironmentVariableA(name, buf, (DWORD)size);
  if (n == 0 || n >= size) buf[0] = 0;
#else
  const char *v = getenv(name);
  snprintf(buf, size, "%s", v ? v : "");
#endif
  return buf;
}

static inline int takkel_hot__fail(takkel_hot *h, const char *what, const char *detail) {
  snprintf(h->error, sizeof h->error, "takkel_hot %s: %s%s%s", h->name, what, detail ? ": " : "", detail ? detail : "");
  return -1;
}

/* The manifest's size and time; nonzero when it cannot be read. */
static inline int takkel_hot__stamp(const char *file, long long *size, long long *time) {
#if defined(_WIN32)
  WCHAR wide[4096];
  WIN32_FILE_ATTRIBUTE_DATA a;
  if (!MultiByteToWideChar(CP_UTF8, 0, file, -1, wide, 4096)) return -1;
  if (!GetFileAttributesExW(wide, GetFileExInfoStandard, &a)) return -1;
  *size = ((long long)a.nFileSizeHigh << 32) | a.nFileSizeLow;
  *time = ((long long)a.ftLastWriteTime.dwHighDateTime << 32) | a.ftLastWriteTime.dwLowDateTime;
#else
  struct stat s;
  if (stat(file, &s) != 0) return -1;
  *size = (long long)s.st_size;
#if defined(__APPLE__)
  *time = (long long)s.st_mtimespec.tv_sec * 1000000000LL + s.st_mtimespec.tv_nsec;
#else
  *time = (long long)s.st_mtim.tv_sec * 1000000000LL + s.st_mtim.tv_nsec;
#endif
#endif
  return 0;
}

static inline FILE *takkel_hot__fopen(const char *file, const char *mode) {
#if defined(_WIN32)
  WCHAR wide[4096], wmode[8];
  if (!MultiByteToWideChar(CP_UTF8, 0, file, -1, wide, 4096)) return NULL;
  if (!MultiByteToWideChar(CP_UTF8, 0, mode, -1, wmode, 8)) return NULL;
  FILE *f = NULL;
  return _wfopen_s(&f, wide, wmode) == 0 ? f : NULL;
#else
  return fopen(file, mode);
#endif
}

/* Reads `"generation":N` and `"file":"…"` from the manifest takkel wrote (no escapes in what it writes there). */
static inline int takkel_hot__read_manifest(takkel_hot *h, int *generation, char *path, size_t path_size) {
  char text[8192];
  FILE *f = takkel_hot__fopen(h->manifest, "rb");
  if (!f) return takkel_hot__fail(h, "cannot open the manifest", h->manifest);
  size_t n = fread(text, 1, sizeof text - 1, f);
  fclose(f);
  text[n] = 0;
  const char *g = strstr(text, "\"generation\":");
  const char *p = strstr(text, "\"file\":\"");
  if (!g || !p) return takkel_hot__fail(h, "the manifest is not one takkel wrote", h->manifest);
  *generation = (int)strtol(g + 13, NULL, 10);
  p += 8;
  const char *end = strchr(p, '"');
  if (!end) return takkel_hot__fail(h, "the manifest is not one takkel wrote", h->manifest);
  /* The file is relative to the manifest's folder. */
  const char *slash = strrchr(h->manifest, '/');
#if defined(_WIN32)
  const char *back = strrchr(h->manifest, '\\');
  if (!slash || (back && back > slash)) slash = back;
#endif
  size_t dir = slash ? (size_t)(slash - h->manifest + 1) : 0;
  size_t len = (size_t)(end - p);
  if (dir + len + 1 > path_size) return takkel_hot__fail(h, "the generation's path is too long", NULL);
  memcpy(path, h->manifest, dir);
  memcpy(path + dir, p, len);
  path[dir + len] = 0;
  return 0;
}

static inline void *takkel_hot__symbol(void *handle, const char *name) {
#if defined(_WIN32)
  return (void *)GetProcAddress((HMODULE)handle, name);
#else
  return dlsym(handle, name);
#endif
}

static inline void takkel_hot__ack(takkel_hot *h, int generation, int ok) {
  char session_buf[256];
  const char *session = takkel_hot__env("TAKKEL_HOT", session_buf, sizeof session_buf);
  if (!*session) return;
  char dir[4200], file[4400], tmp[4500], body[2048], error[1100];
  const char *slash = strrchr(h->manifest, '/');
#if defined(_WIN32)
  const char *back = strrchr(h->manifest, '\\');
  if (!slash || (back && back > slash)) slash = back;
  unsigned long pid = (unsigned long)GetCurrentProcessId();
#else
  unsigned long pid = (unsigned long)getpid();
#endif
  size_t d = slash ? (size_t)(slash - h->manifest + 1) : 0;
  snprintf(dir, sizeof dir, "%.*sacks", (int)d, h->manifest);
  snprintf(file, sizeof file, "%s/%lu-%s.json", dir, pid, h->name);
  snprintf(tmp, sizeof tmp, "%s.%d.tmp", file, generation);
  /* The error as a JSON string: quotes and backslashes escaped, control characters dropped. */
  size_t o = 0;
  for (const char *c = h->error; *c && o + 2 < sizeof error; c++) {
    if (*c == '"' || *c == '\\') error[o++] = '\\';
    if ((unsigned char)*c >= 0x20) error[o++] = *c;
  }
  error[o] = 0;
  if (ok)
    snprintf(body, sizeof body, "{\"session\":\"%s\",\"generation\":%d,\"ok\":true}\n", session, generation);
  else
    snprintf(body, sizeof body, "{\"session\":\"%s\",\"generation\":%d,\"ok\":false,\"error\":\"%s\"}\n", session,
             generation, error);
#if defined(_WIN32)
  WCHAR wdir[4200], wfile[4400], wtmp[4500];
  MultiByteToWideChar(CP_UTF8, 0, dir, -1, wdir, 4200);
  MultiByteToWideChar(CP_UTF8, 0, file, -1, wfile, 4400);
  MultiByteToWideChar(CP_UTF8, 0, tmp, -1, wtmp, 4500);
  CreateDirectoryW(wdir, NULL);
#else
  mkdir(dir, 0777);
#endif
  FILE *f = takkel_hot__fopen(tmp, "wb");
  if (!f) return;
  fputs(body, f);
  fclose(f);
#if defined(_WIN32)
  /* takkel may have the file open for a moment. */
  for (int i = 0; i < 50 && !MoveFileExW(wtmp, wfile, MOVEFILE_REPLACE_EXISTING); i++) Sleep(5);
#else
  rename(tmp, file);
#endif
}

/* Loads the manifest's generation if it is newer: 1 when it switched, 0 when nothing was new, -1 on failure. */
static inline int takkel_hot__load(takkel_hot *h) {
  int generation = 0;
  char path[4600];
  if (takkel_hot__read_manifest(h, &generation, path, sizeof path) != 0) return -1;
  if (generation <= h->tried) return 0;
  h->tried = generation;
#if defined(_WIN32)
  WCHAR wide[4600];
  if (!MultiByteToWideChar(CP_UTF8, 0, path, -1, wide, 4600)) return takkel_hot__fail(h, "bad path", path);
  void *handle = (void *)LoadLibraryW(wide);
  if (!handle) {
    char why[64];
    snprintf(why, sizeof why, "LoadLibraryW failed with error %lu", (unsigned long)GetLastError());
    takkel_hot__fail(h, why, path);
    takkel_hot__ack(h, generation, 0);
    return -1;
  }
#else
  void *handle = dlopen(path, RTLD_NOW | RTLD_LOCAL);
  if (!handle) {
    takkel_hot__fail(h, "dlopen failed", dlerror());
    takkel_hot__ack(h, generation, 0);
    return -1;
  }
#endif
  /* Every symbol first, so a generation missing one changes nothing. */
  void *found[256];
  if (h->count > 256) return takkel_hot__fail(h, "more than 256 symbols", NULL);
  for (size_t i = 0; i < h->count; i++) {
    found[i] = takkel_hot__symbol(handle, h->symbols[i]);
    if (!found[i]) {
      char what[300];
      snprintf(what, sizeof what, "generation %d has no symbol %s", generation, h->symbols[i]);
      takkel_hot__fail(h, what, NULL);
      takkel_hot__ack(h, generation, 0);
      /* Not unloaded: whatever it started while loading may still run. Like every old generation, it stays. */
      return -1;
    }
  }
  if (h->handle) {
    takkel_hot_hook unload = (takkel_hot_hook)takkel_hot__symbol(h->handle, "takkel_hot_on_unload");
    if (unload) unload(&h->state, h->generation);
  }
  for (size_t i = 0; i < h->count; i++) h->table[i] = found[i];
  h->handle = handle;
  h->generation = generation;
  h->error[0] = 0;
  takkel_hot_hook load = (takkel_hot_hook)takkel_hot__symbol(handle, "takkel_hot_on_load");
  if (load) load(&h->state, generation);
  takkel_hot__ack(h, generation, 1);
  return 1;
}

/*
 * Opens the hot library `name` and loads its newest generation into `table` (`count` function pointers named by
 * `symbols`). `manifest` is the manifest's path, or NULL for TAKKEL_HOT_DIR/<name>.json. 0, or -1 with h->error.
 */
static inline int takkel_hot_open(takkel_hot *h, const char *name, const char *manifest, void **table,
                           const char *const *symbols, size_t count) {
  memset(h, 0, sizeof *h);
  snprintf(h->name, sizeof h->name, "%s", name);
  h->table = table;
  h->symbols = symbols;
  h->count = count;
  if (manifest) {
    snprintf(h->manifest, sizeof h->manifest, "%s", manifest);
  } else {
    char dir_buf[4000];
    const char *dir = takkel_hot__env("TAKKEL_HOT_DIR", dir_buf, sizeof dir_buf);
    if (!*dir) return takkel_hot__fail(h, "TAKKEL_HOT_DIR is not set; pass the manifest's path", NULL);
    snprintf(h->manifest, sizeof h->manifest, "%s/%s.json", dir, name);
  }
  takkel_hot__stamp(h->manifest, &h->stamp_size, &h->stamp_time);
  return takkel_hot__load(h) < 0 ? -1 : 0;
}

/*
 * Loads a newer generation if takkel has published one: 1 when it switched, 0 when there was nothing new, -1 when
 * the new generation could not be loaded (h->error says why; the old one stays in the table). One stat when
 * nothing changed, so it can be called every frame.
 */
static inline int takkel_hot_update(takkel_hot *h) {
  long long size = 0, time = 0;
  if (takkel_hot__stamp(h->manifest, &size, &time) != 0) return 0;
  if (size == h->stamp_size && time == h->stamp_time) return 0;
  h->stamp_size = size;
  h->stamp_time = time;
  return takkel_hot__load(h);
}

/* Calls the loaded generation's unload hook. The libraries stay loaded until the process ends. */
static inline void takkel_hot_close(takkel_hot *h) {
  if (h->handle) {
    takkel_hot_hook unload = (takkel_hot_hook)takkel_hot__symbol(h->handle, "takkel_hot_on_unload");
    if (unload) unload(&h->state, h->generation);
  }
  h->handle = NULL;
}

#ifdef __cplusplus
}
#endif

#endif /* TAKKEL_HOT_H */
