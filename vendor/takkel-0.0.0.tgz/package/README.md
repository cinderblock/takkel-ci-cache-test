# takkel

A TypeScript build system for native code. Its command is `tak`. The design is in [docs/design/](docs/design/architecture.md) and the plan in [plans/takkel-build-system.md](plans/takkel-build-system.md). Side-by-side configuration comparisons are in [docs/public/comparison.md](docs/public/comparison.md) (backed by runnable projects under [examples/](examples/README.md)), and build-time measurements against CMake + Ninja, Make, and ccache are in [docs/public/benchmarks.md](docs/public/benchmarks.md).

Milestones M1 to M8, the daemon (M2b), and M9's link-time optimization, unity builds, C++20 modules, Rust addons and the test runner with sanitizers and coverage are implemented. takkel replaces node-gyp for local builds of Node-API addons, with no Python, and builds C and C++ programs, static and shared libraries and tests. It finds the system compiler (MSVC without `vcvarsall.bat`, GCC or Clang), and it needs no config for a project that follows the conventions. Every action's result goes into a content-addressed cache shared by all of a user's workspaces, so a clean build, another branch or a takkel upgrade mostly copies results instead of compiling. Compilers report their diagnostics through structured channels, and takkel shows them its own way, once each, in a live terminal view. It also downloads, pins and verifies toolchains (Zig by default, LLVM releases and llvm-mingw on request) and cross-compiles with them. For Node addons it builds the whole prebuild matrix from one machine, generates a dependency-free loader, and packs and publishes npm platform packages (or a signed, self-hosted release), with Sigstore verification. In development it watches, rebuilds what a change affects, and restarts a program or swaps a rebuilt addon or shared library into it while it runs. It builds dependencies from source (by URL, from git, from a folder) or takes them from the system through their pkg-config files, and answers autoconf's questions with batched, cached probes. A background session per workspace (the daemon) keeps the build graph loaded between builds; it is never required. It shares results between machines through a remote cache, and builds programs whole (LTO, with takkel running Clang's ThinLTO backends itself), in unity batches, or from C++20 modules. It builds Node addons written in Rust with cargo, sharing `-j` with cargo through a GNU make jobserver, and runs tests in parallel with cached results, sanitizers and merged coverage. Not yet: the rest of M9 ([architecture.md 8](docs/design/architecture.md#8-roadmap)).

## Using it

```console
$ tak build                     # or a bare `tak`: debug, into out/
$ tak build --release
$ tak build --layout=gyp        # node-gyp's folders: build/Debug, build/Release
$ tak run app -- --flag         # build, then run
$ tak test ['parse-*'] [-- a]  # build the tests and run them in parallel; passes are cached
$ tak config show [target]      # the effective config, or one target's layered settings
$ tak init                      # write the effective config to takkel.yaml
$ tak clean                     # remove exactly what takkel made
$ tak why app                   # why app's actions ran in the last build; --cache: what changed in their keys
$ tak why src/config.h          # the actions that depend on a file
$ tak trace                     # the last build as a Chrome trace, for ui.perfetto.dev
$ tak cache stats               # the per-user store; also gc [--max-size 10G] and clean
$ tak build --target linux-x64   # a cross build, with a pinned Zig
$ tak lock                      # pin the toolchains and dependencies takkel.yaml declares, in takkel.lock
$ tak update [zig|<dependency>] # resolve them again: toolchain ranges, git tags and branches
$ tak toolchain fetch           # install this configuration's toolchain now; list: what is installed
$ tak import gyp                # write takkel.yaml from a binding.gyp (tak import gyp native/binding.gyp)
$ tak node prebuild             # every platform of the prebuild matrix, into prebuilds/<platform>/
$ tak node sign                 # Authenticode and Apple signatures on the prebuilds (TAKKEL_SIGN_*), before pack
$ tak node pack                 # the loader, the platform packages, package.json's optionalDependencies
$ tak node publish              # platform packages first, the package last; --dry-run, --registry
$ tak node verify userid@2.0.1  # a published release: packages, provenance, a self-hosted manifest
$ tak ci init                   # a CI pipeline with takkel's cache wired in (written, never enabled or run)
$ tak sign verify app.exe       # a platform signature, checked in TypeScript on any OS; tak sign <files> signs
$ tak watch                     # build, then again after every change (also tak build --watch)
$ tak dev -- node server.js     # build, run, restart after each rebuild; without a command, the executable target
$ tak dev --hot -- node app.js  # swap rebuilt addons and hot shared libraries into the running program instead
$ tak daemon start              # this workspace's daemon; also status and stop; --no-daemon on any command keeps it out
```

**The cache.** Before an action runs, takkel looks its key up in the per-user store (`TAKKEL_HOME`, else `%LOCALAPPDATA%\takkel`, `~/Library/Caches/takkel` or `~/.cache/takkel`). A hit copies the outputs out of the store and replays what the tool printed; the plain progress line says `(cached)`. A compile's key covers its source and command; the headers it read are checked through a manifest of the ways they have looked. Outputs that nothing builds any more (a deleted source, a removed target) are deleted, and every build writes an event log under `.build/log` that `tak why` and `tak trace` read.

**Diagnostics.** GCC 13–15 send SARIF on stderr, MSVC 17.8+ sends SARIF through an inherited pipe (with the Windows helper; text otherwise), Clang writes its serialized diagnostics (`.dia`), and every linker is read from its text. takkel draws them all alike: `path:line:col: severity: message [code]`, a code frame, the include chain and notes. A warning that several compiles report (one in a shared header) shows once; warnings outside the project are counted, not shown. They are stored with each action's result, so a cache hit, and a no-op build, shows them again. `--sarif out.sarif` writes them as one SARIF log; under GitHub Actions each is also an annotation.

**Progress.** On a terminal, a live region at the bottom shows each running action with its progress, estimated from its last run, and finished actions' diagnostics scroll above it. Elsewhere (CI, a pipe, `--progress plain`) each finished action is a line with its diagnostics under it. `--progress json` prints the event stream, which a program can also read through `takkel.build()` ([src/takkel.ts](src/takkel.ts)). `tak trace` marks the critical path, and actions that failed last time start first.

**Toolchains.** With nothing declared, takkel builds for this machine with its compiler (an installed MSVC first on Windows, then Clang and GCC; GCC first on Linux) and says so: the summary line reads `(system, non-hermetic)`. A cross build (`--target linux-x64`, `windows-x64`, `macos-arm64`, `linux-arm64-musl`, …) with nothing declared uses takkel's own pinned Zig. A project pins its own in `takkel.yaml`:

```yaml
toolchain: { kind: zig, version: '^0.17' } # or llvm, or llvm-mingw; a list with `if` picks one per platform
```

`tak lock` resolves the range and writes `takkel.lock`: the version, and for every host (Windows, Linux and macOS, x64 and arm64) the download's URL, size and SHA-256. A build only reads the lock. Downloads go to the per-user store under `toolchains/`, checked against the pinned digest (and Zig's minisign signature), unpacked once per machine; Zig builds each target's C library once per user, in the background of the first build for that target. Linux builds with a pinned toolchain need at most glibc 2.28, checked after every link. User config (`%APPDATA%\takkel\config.yaml`, `~/.config/takkel/config.yaml`, or `TAKKEL_CONFIG`) can name mirrors (`mirrors: [https://…]`, or `TAKKEL_MIRRORS`) and the store's cap (`cache: { maxSize: 10G }`); the store is collected automatically past it.

Settings change what is built: `--release`, `--profile`, `--set name=value`, `--target`, `--toolchain msvc|gcc|clang|zig|llvm|llvm-mingw`. Options never do: `-j`, `-k`, `--progress tty|plain|json|quiet`, `--sarif`, `--hot`, `--debounce`, `--poll`, `--no-daemon`, `--serve`, `--verbose`. `tak help` lists them all.

**The dev loop.** `tak watch` watches the folders its inputs live in, with the OS's own notifications (no polling, nothing recursive), waits for a quiet moment (`--debounce`, 100 ms), and builds again; the engine reruns only what the change reaches. Its own outputs never trigger it, and the workspace is free between builds, so `tak build` in another terminal still works. `--poll <ms>` also builds every so often, for folders the OS does not report (network drives, a Windows folder seen from WSL); a folder that cannot be watched is said loudly. `tak dev` adds a program: it starts after the first good build, and after each build that changed a product its whole tree is stopped (SIGTERM to its process group, then SIGKILL; on Windows a Job Object, which also ends it if takkel itself is killed) and it starts again. A failed build leaves it running.

**The daemon** ([architecture.md 1.9](docs/design/architecture.md#19-watch-mode-and-the-daemon)). Every command is a client of a session, which runs either in the command's own process or in the workspace's daemon, a background process that keeps the graph loaded between builds. A command uses the daemon when one is running, and the first build at a terminal starts one (never in CI, under an npm script or without a terminal); `tak daemon start` starts it from anywhere, and `--no-daemon` keeps any command out of it. Builds through it are the same builds: the same session code, the client's environment and working folder for each request, the workspace lock taken only while a request runs (so `--no-daemon` works beside it, and the daemon reloads what that wrote). `tak run` runs the program in the client; `tak test` runs the tests in the build, as cached actions. It is found through a registry file in the per-user store and reached through a named pipe (Windows) or a Unix socket in a folder only the user can enter, after both ends prove they know a token from that file. It exits after 30 idle minutes (`--idle <seconds>`), when its workspace or takkel's own files change or go away, on `tak daemon stop`, or when a client of another takkel version connects (that client then builds without it, or starts a new one). `tak watch` runs its loop in the daemon; a change during a build stops just the actions it affects. `tak watch --serve` (or `takkel.subscribe()`) streams every build's events to editors and other tools. A crashed daemon is noticed and the build runs in-process; its log is `<store>/daemon/<id>.log`, which `tak daemon status` names.

**The native client.** Installed with npm on Linux or macOS, `tak` is a small C program ([native/helper/src/client.c](native/helper/src/client.c)) that sends a build to the workspace's warm daemon without starting Node. A no-op build then takes about 15 ms instead of 80–110 ms. The daemon renders the output, so it matches the JavaScript command's. Anything the client does not handle runs the JavaScript command beside it (`dist/bin.cjs`): a command other than a build, no running daemon, `--no-daemon`, `TAKKEL_NATIVE_CLIENT=0`, a daemon of another takkel, or a takkel package whose version differs from the client's. `--verbose` says on stderr which client ran and why.

It ships the way esbuild ships its binary. Each platform package `@takkel/helper-<platform>` (an optional dependency) carries the client beside the helper. The package's command, `dist/tak`, is published as a JavaScript shim, and its `postinstall` copies the client over it once the client answers `--native-client-version` with the package's own version. When that cannot happen, `tak` stays the JavaScript command and works as before, about 65–95 ms slower per no-op build through the daemon:

- `npm install --ignore-scripts`, and Bun, which runs no install scripts by default.
- pnpm and Yarn, whose shims run `dist/tak` through Node.
- Windows, where npm writes its `.cmd` shim to run `node dist\tak` before install scripts run.
- No platform package for the machine.
- `TAKKEL_NATIVE_CLIENT=0` during the install. Set later, it makes the native client hand every command to the JavaScript one.

To put the client in place after an install that skipped it, or to see why it was skipped, run `node node_modules/takkel/dist/install.cjs --verbose`. `tak --native-client-version` says which `tak` is installed without running a build: it prints the client's version, or says that this `tak` is the JavaScript one and why.

**Hot swap.** With `tak dev --hot`, a rebuilt Node addon is loaded into the running process instead: the local-build pointer the generated loader reads hands the addon to a small shim, so exported functions (even destructured ones) call the newest build, and `binding[Symbol.for('takkel.hot')]` offers `dispose` and `accept` hooks. A plain C or C++ host does the same for a `shared-library` marked `hot: true` through [`takkel/hot.h`](include/takkel/hot.h) (a table of function pointers, re-resolved by `takkel_hot_update()`). Each build is copied to a new path (`.build/hot/<name>/<n>/`), so nothing loaded is ever overwritten. The program acknowledges each load; when it cannot take one (it loaded the addon some other way, a load failed, or something else changed), takkel restarts it and says why. Old generations stay loaded until the process ends.

**Dependencies** ([architecture.md 2.6](docs/design/architecture.md#26-dependencies)). Built from source with the project's own toolchain, profile and platform, in the same graph and cache:

```yaml
dependencies:
  zlib: # an archive, pinned by SHA-256, with an inline recipe: the keys of one target, paths inside the archive
    url: https://github.com/madler/zlib/releases/download/v1.4/zlib-1.4.tar.gz
    sha256: 02dd159783677a749c04adbdd02b55b8a2bcc7e054f51b76b549199a916ad584
    sources: [adler32.c, compress.c, crc32.c, deflate.c, inflate.c, …]
    include: { public: ['.'] }
  inih:
    {
      git: https://github.com/benhoyt/inih,
      rev: 26254ee9de7681f8825433415443e7116ff24b98,
      sources: [ini.c],
      include: { public: ['.'] },
    }
  calc: { path: third_party/calc } # a folder in the workspace, with its own takkel.yaml
  png: { system: true, version: '>= 1.6' } # installed on this machine, found through libpng.pc
  napi: { npm: node-addon-api } # headers from node_modules
targets:
  app: { type: executable, sources: [main.c], deps: [zlib, inih] }
```

- `tak lock` downloads each url archive and checks its digest, resolves a git `tag` or `branch` to its commit (`git ls-remote`, then a shallow fetch of that one commit), and pins the size, the commit and a SHA-256 of the files in `takkel.lock`. A build never resolves: a dependency the lock does not pin, or pins differently, is an error that says to run `tak lock`. git dependencies need the `git` program; files are taken raw from the commit, so `core.autocrlf` changes nothing.
- Each verified tree is unpacked once per machine in the per-user store and copied into the workspace at `.build/deps/<name>@<digest>/`, so its compiles are ordinary cached actions, shared by every workspace. Its warnings are counted, not shown, like system headers'.
- A tree is built by its own `takkel.yaml` when it has one (its targets are `<dependency>/<target>`, and `deps: [<dependency>]` means its library), else by the inline recipe: a `static-library`, or a `header-library` when it names no sources. A recipe may declare `probes` and use them in `when` and `configHeader`.
- `system` dependencies read `.pc` files in TypeScript, no `pkg-config` program needed (`PKG_CONFIG_PATH`, `PKG_CONFIG_LIBDIR`, `PKG_CONFIG_SYSROOT_DIR`, `Requires`, `static: true` for `Libs.private`); without one, the `libs` and `headers` a spec names are looked for in the compiler's own folders. Missing is an error naming every folder searched and the package to install. They are for builds for this machine with its own compiler.

**Probes** ([architecture.md 2.7](docs/design/architecture.md#27-feature-probes)). autoconf's checks, as data:

```yaml
probes:
  HAVE_UNISTD_H: { header: unistd.h }
  SIZEOF_LONG: { sizeOf: long } # also alignOf
  HAVE_STRLCPY: { function: strlcpy, headers: [string.h] }
  HAVE_SIGACTION: { symbol: sigaction, headers: [signal.h] }
  HAVE_BUILTIN_EXPECT: { compiles: 'int f(int x) { return __builtin_expect(x, 1); }' } # also links, flag
targets:
  app:
    type: executable
    sources: [main.c]
    configHeader: config.h # #define HAVE_UNISTD_H 1, /* #undef HAVE_STRLCPY */, #define SIZEOF_LONG 8
    when: [{ if: { probe: { HAVE_UNISTD_H: true } }, sources: [posix.c] }]
```

Probes run in batches: one compile answers every header (`__has_include`), one every size and alignment (read back out of the object file, so nothing runs and cross builds work), one every symbol, one link every function; a failure is pinned on its probe by its line number or the linker's missing symbol, and the rest go again without it. Each answer is cached in the per-user store by the toolchain's identity, the target and the probe (and, for a system compiler, its folders' signatures), so a probe runs once per machine.

**Zero config.** With no `takkel.yaml`, the sources are `src/**` (or the top level), and the target type comes from what they contain: a `package.json` and a source that includes `napi.h` or `node_api.h` make a `node-addon`; one `main` makes an executable; several make one each; none makes a static library. Sources with a `main` under `test/` become tests.

**A Node addon that node-gyp built.** `tak import gyp` writes the `takkel.yaml` (sources, includes, defines, per-OS conditions, node-addon-api's mode; `layout: gyp`, so the package's loader keeps finding the addon), and says in comments what it could not translate. By hand, the target's name is what the loader asks for:

```yaml
targets:
  gyp-test: { type: node-addon, sources: [index.cpp] }
```

Then `tak build --layout=gyp` puts `build/Debug/gyp-test.node` where `bindings` and `node-gyp-build` look. Node-API headers ship with takkel; node-addon-api comes from the project's `node_modules`. On Windows the addon resolves Node-API from whichever executable loads it (node.exe, electron.exe, bun.exe), and it can be rebuilt while a process still has it loaded.

**Shipping a Node addon** ([architecture.md 6.3–6.4](docs/design/architecture.md#64-prebuild-sign-publish)). Say which platforms in `takkel.yaml`:

```yaml
node:
  prebuilds:
    platforms: [linux-x64-gnu, linux-arm64-gnu, linux-x64-musl, darwin-arm64, win32-x64] # npm's names
    distribution: platform-packages # the default; or bundled, or { baseUrl, publicKey } to self-host
    executables: [mytool] # optional: executable targets each platform package also carries
```

- `tak node prebuild` builds every listed platform the addon `supports`, in one graph, with takkel's pinned Zig unless a toolchain is declared (a prebuild must not carry this machine's C library), release, into `prebuilds/<platform>/<name>.node`. The targets listed under `executables` build the same way into `prebuilds/<platform>/<name>` (`.exe` on Windows), and each platform package carries its platform's executables beside the addons, as esbuild's platform packages carry its binary. takkel ships `tak` this way. From Windows that covers Linux (glibc 2.28 and musl, x64, arm64, ARMv7), macOS, FreeBSD and Windows itself.
- `tak node sign` puts platform signatures on the prebuilds, by content: Authenticode on Windows binaries (signtool, on Windows), Apple's on macOS ones (rcodesign, pinned and downloaded on first use, from any OS; codesign on a Mac), nothing on ELF. Credentials come only from the environment: `TAKKEL_SIGN_PFX` + `TAKKEL_SIGN_PFX_PASSWORD`, `TAKKEL_SIGN_THUMBPRINT` or `TAKKEL_SIGN_DLIB` + `TAKKEL_SIGN_DLIB_METADATA` for Windows; `TAKKEL_SIGN_P12` + `TAKKEL_SIGN_P12_PASSWORD`, `TAKKEL_SIGN_PEM_CERT` + `TAKKEL_SIGN_PEM_KEY` or `TAKKEL_SIGN_MACOS_IDENTITY` (or `--adhoc`) for macOS. Policy goes in `takkel.yaml`'s `sign:` section (`windows: { timestamp: <url> | false }`, `macos: { timestamp, hardenedRuntime, entitlements }`); Authenticode with no timestamp choice is an error (`--no-timestamp` for one run). Files already signed with the same certificate are skipped (`--force`), and a pack made before signing is called stale. `tak sign <files>` and `tak sign verify <files> [--json]` do the same for any file; verification is takkel's own, in TypeScript, on every OS, with signtool, rcodesign or codesign as a cross-check.
- `tak node pack` writes the loader, `binding.cjs` and `binding.mjs`: no dependencies, a literal `require` per platform, `TAKKEL_ADDON_<NAME>` to load another file, the checkout's own build first (every `tak build` leaves a pointer to it in the build folder), its own error code where `supports` rules the platform out (`ERR_TAKKEL_UNSUPPORTED_PLATFORM`), and an error that lists what it tried and how to build from source (`ERR_TAKKEL_ADDON_NOT_FOUND`). It stages one package per platform in `.build/npm/<platform>/` (with `os`, `cpu` and `libc`, so a package manager installs only one) and sets package.json's `optionalDependencies` to exactly those at its version, keeping its formatting. Use it as `prepack`.
- `tak node publish` packs, then publishes the platform packages, then the package, skipping versions the registry has, so a rerun resumes. Under GitHub Actions with an OIDC token it asks npm for provenance. `tak ci init` writes the workflow that does this: one Linux runner for everything Zig builds, Sigstore attestations for every binary, npm trusted publishing. It prints a rough cost and enables nothing.
- **Self-hosted:** `tak node keygen --out <file>` makes a minisign key pair; with `distribution: { baseUrl, publicKey }`, `tak node pack --key <file>` (or `TAKKEL_SIGNING_KEY`) stages `.build/self-hosted/<name>/v<version>/`: each binary gzipped, `manifest.json` and its signature. The package gets a generated `install.cjs` (no dependencies) that checks the signature against the key in package.json, then each file's SHA-256. `tak node publish` publishes the package only once the host serves that manifest.
- `tak node verify [name@version]` checks a release: every platform package, npm provenance and GitHub attestations (Sigstore, through the optional peer dependency `sigstore`), and a self-hosted manifest and its files.

**Sharing results** ([architecture.md 1.7](docs/design/architecture.md#17-remote-cache)). A remote cache serves every machine what one of them compiled:

```sh
TAKKEL_REMOTE_CACHE=https://cache.example.com tak build    # Bazel's HTTP cache layout (bazel-remote, nginx, a bucket)
TAKKEL_REMOTE_CACHE=grpcs://cache.example.com:443 tak build   # REAPI over gRPC (bazel-remote, Buildbarn, BuildBuddy)
TAKKEL_REMOTE_CACHE=gha tak build                          # GitHub Actions' own cache (picked by itself; below)
```

- Or `--remote-cache <url>`, or `remoteCache: { url, mode, token, auth, timeout, instance }` in user config. The token comes from `TAKKEL_REMOTE_CACHE_TOKEN` or user config (sent as `Authorization: Bearer`, or basic auth with `auth: basic` or credentials in the URL), never from the command line, and is never printed.
- **Read-only for developers, written by CI:** the mode is `read` unless `CI` (or a CI service's own variable) is set; `--remote-cache-mode read-write` or `TAKKEL_REMOTE_CACHE_MODE` says otherwise. Failures are never uploaded. REAPI needs the optional peer dependency `@grpc/grpc-js`.
- **It never fails a build.** A server that cannot be reached, times out (10 s per request; `TAKKEL_REMOTE_CACHE_TIMEOUT`), refuses the token or answers nonsense gets one warning, and the build goes on without it. Plain `http://` and `grpc://` are for a server on this machine only; anything else is TLS, verified.
- A no-op build never asks the remote cache or reads its configuration. Compiles share by the content of every header they read, system headers included, so two machines with different SDKs or C libraries never swap objects; takkel's own folder and the per-user store are named, not spelled out, so another install of takkel shares too.

**Warm builds on CI.** Hosted CI jobs start with an empty store. Run `tak ci init` to write a pipeline that keeps the store in the CI's cache. It picks the CI from `--provider`, the CI files already in the repository, or the host of the `origin` remote. If that CI's pipeline file already exists, it prints the job for you to merge and leaves the file alone.

- **GitHub Actions:** results are shared one by one through GitHub Actions' cache service. A job reads results cached by its own branch, the base branch of its pull request, and the default branch. GitHub gives the service's address and token only to action steps, not to `run:` steps, so the workflow exports them with a one-line `actions/github-script` step. Once they are exported, takkel uses the service automatically; `TAKKEL_REMOTE_CACHE=off` opts out. Here `tak ci init` writes the Node addon release workflow (prebuild, attest, and publish). For your own build-and-test workflow, copy its `actions/github-script` step in front of the steps that run takkel.
- **GitLab CI, Azure Pipelines, CircleCI, and Bitbucket Pipelines:** none of them lets a running job call its cache, so the CI saves the whole store (`TAKKEL_HOME`) after a job and restores it before the next. `tak ci init` writes a build-and-test job with that cache configured. Azure Pipelines and CircleCI can't overwrite a cache, so each run saves a new one and the next run restores the newest. GitLab CI overwrites its cache in place, but by default keeps separate caches for protected and unprotected branches, so a feature branch doesn't start from the default branch's cache. Bitbucket Pipelines saves a cache only when none exists, so it refreshes weekly, when the old one expires.
- **Buildkite, Jenkins, and self-hosted runners:** `tak ci init` writes nothing for these. Their agents usually keep their disk between builds, so the store stays warm on its own. To share results between agents, or on agents that start empty, use a remote cache (`TAKKEL_REMOTE_CACHE`, above).
- **Cache size:** on the five CI services above, takkel trims compiled results after every build that adds new ones, so the saved cache stays small. The cap comes from `TAKKEL_CACHE_MAX_SIZE`, then `cache.maxSize` in user config, then 2 GiB (1 GiB on Bitbucket Pipelines, which rejects caches over 1 GB compressed). Toolchains don't count toward it. Elsewhere, the default cap is 10 GiB, checked every 500 new results or once a day.

**Checking what the cache relies on.** `tak doctor hermetic [targets]` ([architecture.md 1.10](docs/design/architecture.md#110-hermeticity-without-a-sandbox)) builds the request again with a fresh state and runs every action a second time in a scratch folder holding only what it declares (and the headers it reported). An action that fails there, or writes other bytes, reads something it does not declare, such as a file named only in a raw flag (`/DEF:lib.def`, `-Wl,--version-script=lib.map`); list it in the target's `inputs`. It also says which outputs depend on the folder they are built in (MSVC's debug objects do) and whether the toolchain is pinned. Exit code 1 when it finds an undeclared input; a CI job.

**Whole programs, unity builds, modules** (M9; [toolchains.md 4.5](docs/design/toolchains.md#45-lto-and-whole-program-builds)):

```yaml
profiles:
  release: { lto: thin } # or full; per target too. MSVC: /GL and /LTCG; GCC: -flto (WHOPR); Clang: -flto with lld
targets:
  engine: { type: static-library, sources: [src/engine/*.cpp], unity: true } # 8 sources per batch (unityBatch)
  app: { type: executable, sources: [src/*.cpp, src/*.cppm], deps: [engine] } # module units: modules are on
```

- **ThinLTO with takkel as the distributor.** With Clang and lld 21 or newer (Linux, Windows), lld hands its backend compiles to takkel, and each is an action: cached, shared through the remote cache, run within `-j`. After an edit, only the modules it changed are compiled again by the linker. `ltoDistribute: false` keeps ThinLTO inside lld.
- **Unity builds** compile a target's sources a batch at a time. Each source is included as itself, with `TAKKEL_UNITY_ID` defined to a name of its own (`namespace TAKKEL_UNITY_ID { … }` keeps file-local names apart); a source that still clashes goes in `unityExclude`. `compile_commands.json` keeps an entry per source.
- **Faster linkers.** With GCC or Clang from the system linking for Linux or FreeBSD, takkel links with mold, or else lld, when one is installed (`ld.mold`, `ld.lld` beside the compiler or on PATH) and the link allows it: no linker script, no `-fuse-ld=` of its own, and GCC's LTO only with mold. The linker is part of the link's key. `link: { linker: default }` keeps the system's; `mold` or `lld` asks for one (an error when it is missing).
- **C++20 modules** are scanned with the compiler's own P1689 scanner (`clang-scan-deps`, `cl /scanDependencies`, GCC 14's `-fdeps-format=p1689r5`), and each module's BMI is built before what imports it, across targets. A compiler that cannot scan (GCC 13, Zig) says so. Header units and `import std` are not built yet.

**Tests, sanitizers, coverage** (M9). `tak test` builds the test targets (and sources with a `main` under `test/`) and runs each as an action of the build: in parallel within `-j`, stopped and failed past `timeoutSeconds` (300 s unless a target says otherwise), with what a failing test printed shown under it. A test that passed is not run again until its program or inputs change: its pass comes from the action cache (and from the remote cache), while a failure runs every time. `tak test 'parse-*'` runs the tests a glob names; `tak test -- args` passes arguments to each.

```yaml
profiles:
  asan: { sanitize: [address, undefined] } # thread and memory too, where the compiler has them
```

- **Sanitizers** are a profile or target setting. MSVC has `address`; Clang has all four on Linux, `address` and `undefined` on Windows; GCC has `address`, `undefined` and `thread`. Asking a compiler for one it lacks is an error that says what it has. Undefined behaviour stops the program, so the test fails.
- **Coverage** is the built-in `coverage` profile (or `coverage: true` in one of yours): `tak test --profile coverage` writes one LCOV report, `out/coverage/lcov.info`, merged from every test, with Clang (llvm-cov) or GCC (gcov). MSVC is not supported yet.

**Rust addons** (M9; [architecture.md 6.7](docs/design/architecture.md#67-rust-addons-legacy-addons-migration)):

```yaml
targets:
  hello: { type: node-addon, cargo: { manifest: Cargo.toml } } # its cdylib becomes out/hello.node
```

cargo builds the crate (with a committed `Cargo.lock`) as one action of the build: cached like any other, rebuilt when any source of any crate in it changes, its errors shown as diagnostics, its jobs taken from takkel's jobserver. The Rust toolchain is the one rustup picks for the crate's folder, or a release takkel pins and downloads (`cargo: { manifest: Cargo.toml, toolchain: { kind: rust, version: 1.100.0 } }` and `tak lock`). The loader, prebuilds (for the build machine's OS) and packing are the same as for C.

`takkel.yaml` holds targets, `shared` settings, `when` blocks, `key-` removals, `settings`, `profiles`, `layout`, `dependencies`, `probes` and plugins (local, `plugins: [./tools/x.ts]`, or installed packages, `plugins: [@takkel/embedded]`, whose task results are cached with everything their module imports); [architecture.md 2](docs/design/architecture.md#2-configuration) describes every key. The plugin API is in [src/index.ts](src/index.ts), and [test/fixtures/custom-plugin](test/fixtures/custom-plugin) is an example.

**Firmware** (M9c; [architecture.md 8](docs/design/architecture.md#8-roadmap), [packages/embedded](packages/embedded/src/index.ts)). With the `@takkel/embedded` plugin, a target names its own platform and processor, and builds beside the host tools in the same graph:

```yaml
plugins: ['@takkel/embedded']
toolchain:
  - { if: { os: none, arch: arm }, use: { kind: arm-none-eabi-gcc, version: 15.2.rel1 } } # Arm's, pinned by tak lock
  - { if: { os: none, arch: avr }, use: { kind: avr-gcc, version: 7.3.0-atmel3.6.1-arduino7 } } # Arduino's
targets:
  firmware:
    type: executable
    platform: { os: none, arch: arm, abi: eabi, cpu: cortex-m0plus } # -mcpu=cortex-m0plus -mthumb
    sources: [src/**/*.c, src/crt0.S]
    link: { script: memmap.ld } # an input of the link; on a library, for the programs that link it
    images: [hex, bin, uf2] # beside out/firmware.elf, made in TypeScript; a size report after each link
    uf2: { family: rp2040 }
    memory: { flash: 2M, ram: 264K }
  upload: # tak run upload: picotool (or openocd, avrdude), after building the image; never cached
    type: flash
    platform: { os: none, arch: arm, abi: eabi, cpu: cortex-m0plus }
    image: firmware
    tool: picotool
```

`rp2040-boot2` makes the RP2040's boot stage 2 with its checksum (the Pico SDK's `pad_checksum`, without Python), and `wholeArchive: true` on a library links every member, as CMake's object libraries do. [test/fixtures/embedded/rp2040](test/fixtures/embedded/rp2040/takkel.yaml) builds the Pico SDK 1.4.0's `pico_stdlib` this way, with no CMake.

## Comparisons and benchmarks

- **[Config comparison](docs/public/comparison.md)** — side-by-side build configurations for seven projects (plain C, URL dependency with `zlib`, the `userid` Node-API addon, a Rust Node-API addon, `fmt` 12.2.1, feature probes with `config.h`, and an RP2040 Pico SDK counter-example), backed by verified files under [examples/](examples/README.md).
- **[Benchmarks](docs/public/benchmarks.md)** — build-time measurements against CMake + Ninja, CMake + GNU Make, and Ninja + ccache on Lua, libuv, fmt, and curl, with methodology, fairness rules, and where takkel is faster or slower.

## Layout

| Path                       | What                                                                                                                                                                                                                            |
| -------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `src/cli.ts`               | The command line: it only talks to a session                                                                                                                                                                                    |
| `src/cli/`                 | Arguments and the build's output, shared with `client.ts`: the bundle's first stop, which builds through a warm daemon without loading the rest                                                                                 |
| `src/daemon/`              | The daemon: its registry and address, the handshake, the server (one request at a time, the client's environment) and the client session                                                                                        |
| `src/config/`              | `takkel.yaml`: schema, validation, layers and conditions, zero-config conventions, the `project` key                                                                                                                            |
| `src/toolchain/`           | Toolchains: system discovery (vswhere and the Windows SDK, `PATH`), the compiler adapters (GCC, Clang, MSVC, Zig), `takkel.lock`, the fetcher, the store, unpacking (zip, tar, gzip, zstd, xz) and verification (SRI, minisign) |
| `src/rules/`               | takkel's rule set: configuration, per-target layering, analysis (every action planned as data), one key per action, the Node plugin's build half, local plugins, `compile_commands.json`                                        |
| `src/engine/`              | Keys, the evaluator (sweep, dirty cone, verify, early cutoff, cycles, cancellation), and the built-in keys: files inside and outside the workspace, listings, environment, globs                                                |
| `src/store/`               | The graph state: a snapshot of typed arrays plus an append-only journal; the workspace lock; the per-user store (CAS and action cache)                                                                                          |
| `src/build/`               | Actions: ActionKeys, temp-then-rename outputs (renamed aside when locked), response files, dependency channels; takkel's entries on a remote cache, machine paths in keys                                                       |
| `src/remote/`              | The remote cache: configuration, the policy (modes, one warning, uploads), takkel's protobuf codec, and the backends: Bazel's HTTP layout, REAPI over gRPC, GitHub Actions' cache                                               |
| `src/doctor/`              | `tak doctor hermetic`                                                                                                                                                                                                           |
| `src/exec/`                | The slot scheduler; command-line quoting and response files                                                                                                                                                                     |
| `src/platform/`            | The runtime-portable platform layer; the native helper, loaded at first use, with JavaScript fallbacks when it is absent                                                                                                        |
| `native/helper/`           | The native helper, a Node-API addon in C built by takkel itself (on Windows: directory enumeration, inheritable pipes, and Job Objects; elsewhere: `posix_spawn`), and the native client, `tak`, in C                           |
| `src/install/`             | The `takkel` package's install script, which puts the native client in place of the JavaScript `tak`, and the lookup of the client in its platform package                                                                      |
| `src/session/`             | Sessions: in-process (it lets the workspace go between requests and keeps the graph), and a client for one in a child process; event logs                                                                                       |
| `src/inspect/`             | `tak why` and `tak trace`, over the event logs                                                                                                                                                                                  |
| `src/diagnostics/`         | Structured capture: SARIF (GCC, MSVC's JSON-RPC), Clang's `.dia` bitstream, text for every compiler and linker, paths into the workspace                                                                                        |
| `src/ui/`                  | What a build shows: de-duplication, takkel's own rendering with code frames, the live region, plain lines, GitHub annotations, SARIF export                                                                                     |
| `src/deps/`                | Dependencies and probes: the spec, locking, the git fetcher, the source-tree store, dependency targets, the pkg-config reader, `system` dependencies, batched probes and config headers                                         |
| `src/node/`                | The Node plugin's distribution half: platforms, the `node:` settings, the generated loader and installer, pack, publish (through npm), minisign, Sigstore and attestations, `tak node verify`, `tak import gyp`                 |
| `src/rules/modules.ts`     | C++20 modules: support per toolchain, P1689 scans read back, imports closed over, GCC's module mapper                                                                                                                           |
| `src/rules/unity.ts`       | Unity builds: batches and the generated files                                                                                                                                                                                   |
| `src/rules/test.ts`        | The test runner: one `test-run` key per test (`runTest` in src/build/action.ts)                                                                                                                                                 |
| `src/rules/coverage.ts`    | Coverage: the model, LCOV and gcov's JSON, the report as planned steps                                                                                                                                                          |
| `src/rules/cargo.ts`       | Rust addons: the cargo action (`src/build/cargo-driver.cjs` is what it runs); `src/toolchain/rust.ts` and `rust-dist.ts` find or download Rust                                                                                  |
| `src/exec/jobserver.ts`    | takkel as a GNU make jobserver: a FIFO on POSIX, a named semaphore on Windows                                                                                                                                                   |
| `src/build/dtlto.ts`       | takkel as lld's ThinLTO distributor: the socket, the job file, a backend action per job (`dtlto-client.cjs` is what lld runs)                                                                                                   |
| `src/rules/prebuild.ts`    | The prebuild matrix as one request                                                                                                                                                                                              |
| `src/ci/`                  | `tak ci init`: the GitHub Actions workflow, and pipelines for GitLab, Azure Pipelines, CircleCI and Bitbucket; which CI a process runs under                                                                                    |
| `src/util/self.ts`         | Where takkel's own files are, from source or installed, and how takkel runs itself                                                                                                                                              |
| `src/standalone/`          | The standalone binary: its entry (takkel's files unpacked into the store, its own scripts run by the binary), and the `@takkel/standalone` launcher                                                                             |
| `src/sign/`                | Platform signatures: DER, PKCS#7 and PKCS#12, Authenticode and Mach-O signatures verified in TypeScript, the signtool, rcodesign and codesign drivers, `tak sign`                                                               |
| `packages/embedded/`       | `@takkel/embedded`: the embedded GCCs as plugin toolchains, images and size reports from ELF files, the RP2040 boot stage 2, flashers                                                                                           |
| `src/takkel.ts`            | The event-stream API: `takkel.build()`, `takkel.watch()` and `takkel.subscribe()` as an `AsyncIterable<BuildEvent>`                                                                                                             |
| `src/watch/`               | Watch mode: the watcher over the OS's notifications, and the loop of builds over a session                                                                                                                                      |
| `src/dev/`                 | `tak dev`: the program's supervisor, hot generations and acknowledgements, the Node shim                                                                                                                                        |
| `include/takkel/hot.h`     | The single-header C helper for hosts of hot shared libraries                                                                                                                                                                    |
| `vendor/node-api-headers/` | The pinned Node-API headers (1.9.0, MIT)                                                                                                                                                                                        |
| `test/fixtures/`           | The 2022 examples with their golden command lines per compiler family                                                                                                                                                           |
| `test/fake/`               | A deterministic fake compiler, archiver and linker for the engine's property tests; test servers for the remote cache (HTTP, REAPI, GitHub Actions' cache), each requiring a token                                              |
| `bench/`                   | The no-op startup measurement and profiling aids                                                                                                                                                                                |
| `bench/compare/`           | takkel against CMake + Ninja, CMake + Make and ccache on real projects (Lua, libuv, fmt, curl), with takkel.yaml generated from CMake's file API; results in [plans/benchmarks.md](plans/benchmarks.md)                         |

## Development

Bun for tooling; takkel runs on Bun and on Node 22.18+, and the tests run on both.

```console
$ bun install
$ bun run typecheck
$ bun run test          # bun test, then node --test; offline
$ bun run test:network  # real downloads (Zig, zlib, a git repository; TAKKEL_NET_LLVM=1, TAKKEL_NET_MINGW=1 for more)
$ bun run bundle        # dist/: cli.cjs, client.cjs, bin.cjs, tak (the JavaScript shim), and install.cjs, as the npm package ships them
$ bun run build:helper  # native/helper/out/: takkel-helper.node, which a checkout then uses, and the native client
$ bun run build:client  # native/helper/out/tak (tak.exe): the native client alone
$ bun run package       # takkel's own npm packages in .build/package/ (CLI, helpers, standalone); --publish <registry>
$ bun scripts/standalone.ts --platform host  # the standalone binary in .build/standalone/release/; all 8 without --platform
$ bun src/cli.ts build -C <project>
```

- The real-build tests use the system compiler and skip, with a message, where there is none. The diagnostics tests also use Clang where it is installed.
- `scripts/capture-diagnostics.ts` captures what real compilers report into `test/fixtures/diagnostics`, the bytes the parser tests read (run it with Bun on Windows, with Node or Bun on Linux).
- The live-region tests run headless: what takkel writes goes into a small terminal emulator (`test/vt.ts`).
- `TAKKEL_UPDATE_GOLDEN=1 bun test test/golden.test.ts` rewrites the golden command lines after an intended change.
- Tests use a store of their own: `test/helpers.ts` points `TAKKEL_HOME` at a temporary folder and sets `TAKKEL_OFFLINE`, so the fast suite never downloads. The network suite keeps one store between runs (`TAKKEL_NET_HOME`, default `<temp>/takkel-net-home`), so Zig is fetched and its libraries built once per machine.
- `TAKKEL_PROPERTY_RUNS` sets the number of random cases in the property tests, and `TAKKEL_PROPERTY_SEED` replays a failing one (fast-check prints the seed).
- `node bench/noop-startup.ts <built project>` measures what a no-op build adds to the runtime's startup (run `bun run bundle` first); `bench/noop-daemon.ts` compares a no-op in-process with one through a warm daemon, alternating them.
- Daemon tests start their own daemons (in the test's own `TAKKEL_HOME`), stop each one and check by its pid that it is gone.
- `bun bench/compare/run.ts` compares takkel, in-process and through its warm daemon with the native client, with CMake + Ninja, CMake + Make and Ninja + ccache on pinned real projects (Linux: needs `cmake`, `ninja`, `make`, `ccache`, GNU `time`; Windows: CMake + Ninja with MSVC, from a developer environment). Run `bun run bundle` and `bun run build:client` first, then copy the client from `native/helper/out/` over the bundle's JavaScript `dist/tak` (on Windows, beside it as `dist/tak.exe`) for the runs through the warm daemon. On Windows also build the native helper (`bun run build:helper`), which an install has; without it takkel runs its slower JavaScript fallbacks. `takkel-gnu-ld` measures `link.linker: auto` against the system's linker. Options and scenarios are at the top of the file.

The project was called tak until 2026-11-20. [docs/design/naming.md](docs/design/naming.md) has the reasons for the change.

The 2022–2023 prototype (jyp → cimp → tak) is preserved on the `legacy-2023`, `legacy-cimp-2022` and `legacy-node-bin-install` branches; see [docs/design/prior-art-own.md](docs/design/prior-art-own.md).

## License

MIT. See [LICENSE](LICENSE).
